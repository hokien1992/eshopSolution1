# ASP.NET Core 3.1 project from TEDU
## Technologies
- ASP.NET Core 3.1 
- Entity Framwork Core 3.1
## Install Package
- Microsoft.EntityFrameworkCore.SqlServer
- Microsoft.EntityFrameworkCore.Design
- Microsoft.EntityFrameworkCore.Tools
## Youtube Tutorial
## How to configure and run
## How to contribute