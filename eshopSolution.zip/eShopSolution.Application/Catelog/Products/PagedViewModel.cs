﻿namespace eShopSolution.Application.Catelog.Products
{
	internal class PagedViewModel<T>
	{
	}
}