﻿using System;
using System.Collections.Generic;
using System.Text;

namespace eShopSolution.Utilities.Constans
{
	public class SystemConstants
	{
		public const string mainConnectionString = "eShopSolutionDb";

		public static string MainConnectionString { get; set; }
	}
}
